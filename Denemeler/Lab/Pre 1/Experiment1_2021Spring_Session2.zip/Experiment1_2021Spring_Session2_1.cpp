#include<stdio.h>

int main()
{
	float  R;
	
	printf("Enter Richter scale number R? \n");
    scanf("%f", &R);
    
    if(R < 5.0)
    {
    	printf("Little or no damage \n"); 
	}
   else if(R >= 5.0 && R < 5.5) 
	{
		printf("Some damage \n"); 
	}
	else if(R >= 5.5 && R < 6.5) 
	{
		printf("Serious damage \n");  
	}	
	else if(R >= 6.5 && R < 7.5) 
	{
		printf("Disaster \n");  
	}
	else
	{
		printf("Catastrophe \n"); 
	}
}
