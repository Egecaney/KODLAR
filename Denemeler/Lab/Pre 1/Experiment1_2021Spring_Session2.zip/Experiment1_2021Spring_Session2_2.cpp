#include <stdio.h>
#include <stdlib.h>
#include <math.h>  
int main()
{   
    int w = 100, theta = 0, counter = 0;
    double mu = 0.6, Fx, Fy, Fs, thetaRadyan;
    
    Fx = w*sin(theta);
    Fy = w*cos(theta);
    Fs = Fy*mu;    
    
    while (Fs > Fx)
    {       
    counter ++;
    theta = theta + 2;
    thetaRadyan = theta*(3.14)/180;
    Fx = w*sin(thetaRadyan);
    Fy = w*cos(thetaRadyan);
    Fs = Fy*mu;   
    }
    printf("The maximum angle : %d \n", theta-2); 
} 


 

