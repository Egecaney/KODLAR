#include <stdio.h>
#include <stdlib.h>
int main()
{   
    int number, num_digit = 0;
    printf(" Please, enter an integer number : ");
    scanf ("%d",&number);
    int hold = number;
    while (number > 9)
    {       
    num_digit ++;
    number = number/10;    
    }
    printf(" ------- **** -------\n"); 
    printf(" The entered number is %d and the number of digits is %d \n", hold, num_digit+1); 
    printf(" \n"); 
    printf(" \n"); 
} 


 

