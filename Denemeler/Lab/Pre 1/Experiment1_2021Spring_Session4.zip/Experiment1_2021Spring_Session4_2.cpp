#include <stdio.h>
#define PI 3.14159
int main(){
	int degree = 0;
	printf("Please enter the angle in degrees: ");
	scanf("%d", &degree);
	float x = degree*PI/180;
	float cos_x = 1 - x*x/2 + x*x*x*x/24 - x*x*x*x*x*x/720 + x*x*x*x*x*x*x*x/40320;
	float sin_x = x - x*x*x/6 + x*x*x*x*x/120 - x*x*x*x*x*x*x/5040 + x*x*x*x*x*x*x*x*x/362880;
	printf("cos(x): %.2f\n", cos_x);
	printf("sin(x): %.2f\n", sin_x);
	
	return 0;
}
