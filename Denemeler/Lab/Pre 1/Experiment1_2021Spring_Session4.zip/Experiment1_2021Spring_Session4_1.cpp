#include <stdio.h>

int main(){
	int movie1 = 0;
	int movie2 = 0;
	int movie3 = 0;
	int movie4 = 0;
	int movie5 = 0;
	int total = 0;
	
	printf("How many peeople watched 'Nice Time'?\n");
	scanf("%d", &movie1);
	total += movie1;
	printf("How many peeople watched 'Emine Holmes'?\n");
	scanf("%d", &movie2);
	total += movie2;
	printf("How many peeople watched 'The Return of the Zoom'?\n");
	scanf("%d", &movie3);
	total += movie3;
	printf("How many peeople watched '21st Century Cats'?\n");
	scanf("%d", &movie4);
	total += movie4;
	printf("How many peeople watched 'The Turkishman'?\n");
	scanf("%d", &movie5);
	total += movie5;
	
	printf("'Nice Time' : %.0f%%\n", 100*(float)movie1/total);
	printf("'Emine Holmes' : %.0f%%\n", 100*(float)movie2/total);
	printf("'The Return of the Zoom' : %.0f%%\n", 100*(float)movie3/total);
	printf("'21st Century Cats' : %.0f%%\n", 100*(float)movie4/total);
	printf("'The Turkishman' : %.0f%%\n", 100*(float)movie5/total);
	
	if(movie1>movie2 && movie1>movie3 && movie1>movie4 && movie1>movie5)
	printf("The best movie of this season is Nice Time with percentage %.0f%%\n", 100*(float)movie1/total);
	if(movie2>movie1 && movie2>movie3 && movie2>movie4 && movie2>movie5)
	printf("The best movie of this season is Emine Holmes with percentage %.0f%%\n", 100*(float)movie2/total);
	if(movie3>movie2 && movie3>movie1 && movie3>movie4 && movie3>movie5)
	printf("The best movie of this season is The Return of the Zoom with percentage %.0f%%\n", 100*(float)movie3/total);
	if(movie4>movie2 && movie4>movie3 && movie4>movie1 && movie4>movie5)
	printf("The best movie of this season is 21st Century Cats with percentage %.0f%%\n", 100*(float)movie4/total);
	if(movie5>movie2 && movie5>movie3 && movie5>movie4 && movie5>movie1)
	printf("The best movie of this season is The Turkishman with percentage %.0f%%\n", 100*(float)movie5/total);
	
	if(movie1<movie2 && movie1<movie3 && movie1<movie4 && movie1<movie5)
	printf("The worst movie of this season is Nice Time with percentage %.0f%%\n", 100*(float)movie1/total);
	if(movie2<movie1 && movie2<movie3 && movie2<movie4 && movie2<movie5)
	printf("The worst movie of this season is Emine Holmes with percentage %.0f%%\n", 100*(float)movie2/total);
	if(movie3<movie2 && movie3<movie1 && movie3<movie4 && movie3<movie5)
	printf("The worst movie of this season is The Return of the Zoom with percentage %.0f%%\n", 100*(float)movie3/total);
	if(movie4<movie2 && movie4<movie3 && movie4<movie1 && movie4<movie5)
	printf("The worst movie of this season is 21st Century Cats with percentage %.0f%%\n", 100*(float)movie4/total);
	if(movie5<movie2 && movie5<movie3 && movie5<movie4 && movie5<movie1)
	printf("The worst movie of this season is The Turkishman with percentage %.0f%%\n", 100*(float)movie5/total);
	
	return 0;
}
