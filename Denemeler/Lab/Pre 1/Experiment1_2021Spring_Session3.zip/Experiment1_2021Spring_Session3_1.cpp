#include <stdio.h>

int main() {
    int num, originalNum, remainder, result = 0;
    int digitCount = 0;
    printf("Enter a three-digit integer: ");
    scanf("%d", &num);
    originalNum = num;
    
    while (originalNum != 0) {
    	digitCount++;
    	remainder = originalNum % 10;
       	originalNum /= 10;
    }
    
    originalNum = num;
    while (originalNum != 0) {
        remainder = originalNum % 10;
        
        int tempNum = 1;
        for(int i = 0; i < digitCount; i++)
        	tempNum *= remainder;
        	
        result += tempNum;
       	originalNum /= 10;
    }
    
    if (result == num)
        printf("%d is an Armstrong number.", num);
    else
        printf("%d is not an Armstrong number.", num);

    return 0;
}
