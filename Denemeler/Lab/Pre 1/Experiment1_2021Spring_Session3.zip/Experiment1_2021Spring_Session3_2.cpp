#include <stdio.h>

int main() {
    int running_score = 0;
    int weight_score = 0;
    int climbing_score = 0;
    int reflex_score = 0;
    int total_socre = 0;
    
    double running_coefficient = 0.38;
    double weight_coefficient = 0.22;
    double climbing_coefficient = 0.25;
    double reflex_coefficient = 0.15;

	while(1)
	{
		double total_score = 0;
		
		printf("Running score: ");
    	scanf("%d", &running_score);
    	if(running_score == 0)
    		break;
    	else
    		total_score += running_score * running_coefficient;
    	
    	printf("Weight lifting score: ");
    	scanf("%d", &weight_score);
    	if(weight_score == 0)
    		break;
    	else
    		total_score += weight_score * weight_coefficient;
    	
    	printf("Climbing score: ");
    	scanf("%d", &climbing_score);
    	if(climbing_score == 0)
    		break;
    	else
    		total_score += climbing_score * climbing_coefficient;
    	
    	printf("Reflex score: ");
    	scanf("%d", &reflex_score);
    	
    	if(reflex_score == 0)
    		break;
    	else
    		total_score += reflex_score * reflex_coefficient;
    		
    	if (total_score > 50)
	        printf("This member is succeed, score is  %f, difference is %f.\n\n", total_score, total_score-50);
	    else
	        printf("This member is failed, score is  %f, difference is %f.\n\n", total_score, 50-total_score);
    	
	}

    return 0;
}
